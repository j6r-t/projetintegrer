package com.projetintegration.projetintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetintegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
