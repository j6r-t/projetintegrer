package com.projetintegration.projetintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetintegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetintegrationApplication.class, args);
	}

}
