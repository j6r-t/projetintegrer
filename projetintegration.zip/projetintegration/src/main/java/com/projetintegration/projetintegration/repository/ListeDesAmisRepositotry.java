package com.projetintegration.projetintegration.repository;

import com.projetintegration.projetintegration.entity.Listedesamis;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ListeDesAmisRepositotry extends JpaRepository<Listedesamis,Long> {
}
